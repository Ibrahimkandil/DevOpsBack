package tn.esprit.spring.entities;

public enum TypeCourse {
    COLLECTIVE_CHILDREN, COLLECTIVE_ADULT, INDIVIDUAL
}
