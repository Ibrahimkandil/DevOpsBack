package tn.esprit.spring.entities;

public enum TypeSubscription {
	ANNUAL, MONTHLY, SEMESTRIEL
}
